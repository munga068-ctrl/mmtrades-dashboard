# MMTrades — Framework Playbook Dashboard

A TradeZella-style "playbook" view for your AM/PM Framework tags, built from
your Notion DASHBOARD trades table. Shows a card per framework (win rate,
net P&L, profit factor, expectancy, avg win/loss, mini equity sparkline) plus
a combined line chart of cumulative P&L per framework over time — same idea
as your existing `mmtrades-dashboard` embed, styled to match.

## Folder layout

```
playbook/
  index.html        -> the dashboard page (reads data.json)
  data.json          -> generated data snapshot (committed by the sync job)
  sync_notion.py      -> pulls fresh data from Notion, rewrites data.json
.github/workflows/
  sync-playbook-data.yml  -> runs sync_notion.py on a schedule + pushes the update
```

Drop this whole thing into your existing `mmtrades-dashboard` repo (or a new
repo) at the same level as your current dashboard, keeping the `playbook/`
folder name — the workflow assumes that path.

## 1. Create a Notion integration

1. Go to https://www.notion.so/my-integrations → **New integration**.
2. Name it (e.g. "MMTrades Sync"), internal integration, submit.
3. Copy the **Internal Integration Token** — this is `NOTION_TOKEN`.

## 2. Share your databases with the integration

In Notion, open each of these and use **···  → Connect to → MMTrades Sync**:
- Your DASHBOARD / trades table (the one with `REALIZED PNL`, `OUTCOME`,
  `🟦 AM FRAMEWORK`, `🟧 PM FRAMEWORK`)
- `AM FRAMEWORK` database
- `PM FRAMEWORK` database

## 3. Get the three data source IDs

Open each database as a full page in the browser and copy the ID from the
URL — the 32-character string right after your workspace name and before any
`?v=`:

```
https://www.notion.so/yourspace/<DATA_SOURCE_ID>?v=...
```

You need:
- `NOTION_TRADES_DATA_SOURCE_ID`
- `NOTION_AM_FRAMEWORK_DATA_SOURCE_ID`
- `NOTION_PM_FRAMEWORK_DATA_SOURCE_ID`

If `sync_notion.py` can't find your properties, double-check the property
names at the top of the file (`PROP_DATE`, `PROP_PNL`, `PROP_OUTCOME`,
`PROP_AM_REL`, `PROP_PM_REL`) match your actual column names exactly,
including emoji and trailing spaces.

## 4. Add GitHub repo secrets

In your GitHub repo: **Settings → Secrets and variables → Actions → New
repository secret**, add:
- `NOTION_TOKEN`
- `NOTION_TRADES_DATA_SOURCE_ID`
- `NOTION_AM_FRAMEWORK_DATA_SOURCE_ID`
- `NOTION_PM_FRAMEWORK_DATA_SOURCE_ID`

## 5. Enable GitHub Pages

**Settings → Pages → Source: Deploy from a branch → main → / (root)**
(same as your current `mmtrades-dashboard` setup).

Your dashboard will be live at:
```
https://<your-username>.github.io/<repo>/playbook/
```

## 6. Turn on the sync workflow

The workflow in `.github/workflows/sync-playbook-data.yml` runs twice a day
(06:00 and 22:00 UTC) and on manual trigger. It re-pulls Notion, recomputes
every framework's stats, and commits the new `data.json` straight to `main`
— GitHub Pages picks it up automatically, no rebuild step needed since it's
a static JSON fetch.

To run it immediately: go to the **Actions** tab → **Sync Framework
Playbook Data** → **Run workflow**.

To change the schedule, edit the `cron` line in the workflow file.

## 7. Embed it in Notion

On your Daily Summary / Dashboard page, add an **Embed** block (same as your
current `mmtrades-dashboard` embed) pointing at:
```
https://<your-username>.github.io/<repo>/playbook/
```

## Notes on how frameworks are attributed

Your trades can carry more than one AM/PM Framework tag at once (multiple
macro windows firing on the same trade). Rather than force a single
"the" playbook per trade like TradeZella does, this dashboard credits the
full trade P&L to **every** framework tagged on it — so a trade with two
tags shows up in both cards. That's why the sum of all frameworks' net P&L
won't exactly equal your total account P&L. If you'd rather each trade only
count toward one primary framework, that's a quick change to
`sync_notion.py` (pick `frameworks[0]` instead of looping over all of them).
